//==============================================================================//
//    Unicate Gaming RPG - Novi Modern Register/Login TextDraw System          //
//    Developer: Beka                                                           //
//    Vlasnici: Beka & Sloba                                                    //
//==============================================================================//

// ========================= NEW LOGIN TD SYSTEM ============================== //

stock NewLoginTDCreate(playerid)
{
    // Pozadina - full screen crno sa gradijentom
    NewLoginTD[playerid][0] = CreatePlayerTextDraw(playerid, -2.000000, -4.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][0], 0.000000, 51.500000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][0], 642.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][0], 128);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][0], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][0], 0);

    // Pozadinski panel - lijevi tamno plavi
    NewLoginTD[playerid][1] = CreatePlayerTextDraw(playerid, -2.000000, -4.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][1], 0.000000, 51.500000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][1], 220.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][1], 592137216);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][1], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][1], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][1], 0);

    // Linija - vertikalna izmedju panela
    NewLoginTD[playerid][2] = CreatePlayerTextDraw(playerid, 217.000000, -4.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][2], 0.000000, 51.500000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][2], 3.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][2], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][2], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][2], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][2], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][2], 0);

    // Logo text "UNICATE"
    NewLoginTD[playerid][3] = CreatePlayerTextDraw(playerid, 25.000000, 60.000000, "UNICATE");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][3], 0.700000, 2.500000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][3], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][3], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][3], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][3], 1);

    // Logo text "GAMING"
    NewLoginTD[playerid][4] = CreatePlayerTextDraw(playerid, 25.000000, 90.000000, "GAMING");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][4], 0.700000, 2.500000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][4], -1);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][4], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][4], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][4], 1);

    // Logo text "RPG"
    NewLoginTD[playerid][5] = CreatePlayerTextDraw(playerid, 25.000000, 120.000000, "R P G");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][5], 0.400000, 1.500000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][5], 0x0074c288);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][5], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][5], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][5], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][5], 1);

    // Dekorativna linija ispod logoa
    NewLoginTD[playerid][6] = CreatePlayerTextDraw(playerid, 25.000000, 155.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][6], 0.000000, 0.150000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][6], 170.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][6], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][6], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][6], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][6], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][6], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][6], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][6], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][6], 0);

    // Vlasnici tekst
    NewLoginTD[playerid][7] = CreatePlayerTextDraw(playerid, 25.000000, 175.000000, "VLASNICI");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][7], 0.150000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][7], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][7], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][7], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][7], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][7], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][7], 1);

    NewLoginTD[playerid][8] = CreatePlayerTextDraw(playerid, 25.000000, 190.000000, "Beka & Sloba");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][8], 0.200000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][8], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][8], -1);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][8], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][8], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][8], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][8], 1);

    // Developer tekst
    NewLoginTD[playerid][9] = CreatePlayerTextDraw(playerid, 25.000000, 220.000000, "DEVELOPER");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][9], 0.150000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][9], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][9], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][9], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][9], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][9], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][9], 1);

    NewLoginTD[playerid][10] = CreatePlayerTextDraw(playerid, 25.000000, 235.000000, "Beka");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][10], 0.200000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][10], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][10], -1);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][10], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][10], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][10], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][10], 1);

    // Mapper tekst
    NewLoginTD[playerid][11] = CreatePlayerTextDraw(playerid, 25.000000, 265.000000, "MAPPER");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][11], 0.150000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][11], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][11], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][11], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][11], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][11], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][11], 1);

    NewLoginTD[playerid][12] = CreatePlayerTextDraw(playerid, 25.000000, 280.000000, "Beka");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][12], 0.200000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][12], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][12], -1);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][12], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][12], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][12], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][12], 1);

    // Dekorativna linija 2
    NewLoginTD[playerid][13] = CreatePlayerTextDraw(playerid, 25.000000, 315.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][13], 0.000000, 0.150000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][13], 170.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][13], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][13], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][13], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][13], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][13], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][13], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][13], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][13], 0);

    // Forum info u lijevom panelu
    NewLoginTD[playerid][14] = CreatePlayerTextDraw(playerid, 25.000000, 330.000000, "www.ug-ogc.com");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][14], 0.130000, 0.700000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][14], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][14], 0xAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][14], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][14], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][14], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][14], 1);

    // =========== DESNA STRANA - LOGIN PANEL =========== //

    // Login panel pozadina
    NewLoginTD[playerid][15] = CreatePlayerTextDraw(playerid, 250.000000, 100.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][15], 0.000000, 22.000000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][15], 365.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][15], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][15], 2281701503);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][15], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][15], 2281701503);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][15], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][15], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][15], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][15], 0);

    // Login panel border top
    NewLoginTD[playerid][16] = CreatePlayerTextDraw(playerid, 250.000000, 100.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][16], 0.000000, 0.400000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][16], 365.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][16], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][16], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][16], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][16], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][16], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][16], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][16], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][16], 0);

    // Login panel border bottom
    NewLoginTD[playerid][17] = CreatePlayerTextDraw(playerid, 250.000000, 337.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][17], 0.000000, 0.400000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][17], 365.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][17], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][17], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][17], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][17], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][17], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][17], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][17], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][17], 0);

    // "DOBRADOSLI" naslov
    NewLoginTD[playerid][18] = CreatePlayerTextDraw(playerid, 275.000000, 115.000000, "DOBRADOSLI NA");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][18], 0.250000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][18], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][18], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][18], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][18], 0x00000033);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][18], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][18], 1);

    // "UNICATE GAMING" naslov
    NewLoginTD[playerid][19] = CreatePlayerTextDraw(playerid, 275.000000, 134.000000, "UNICATE GAMING");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][19], 0.400000, 1.600000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][19], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][19], -1);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][19], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][19], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][19], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][19], 1);

    // Igrac ime label
    NewLoginTD[playerid][20] = CreatePlayerTextDraw(playerid, 275.000000, 170.000000, "IME:");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][20], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][20], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][20], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][20], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][20], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][20], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][20], 1);

    // Igrac ime value (biti ce postavljeno dinamicki)
    NewLoginTD[playerid][21] = CreatePlayerTextDraw(playerid, 310.000000, 170.000000, "Ime_Prezime");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][21], 0.220000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][21], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][21], -1);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][21], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][21], 0x00000033);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][21], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][21], 1);

    // Separator line
    NewLoginTD[playerid][22] = CreatePlayerTextDraw(playerid, 275.000000, 193.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][22], 0.000000, 0.100000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][22], 325.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][22], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][22], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][22], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][22], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][22], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][22], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][22], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][22], 0);

    // LOKINKA field label
    NewLoginTD[playerid][23] = CreatePlayerTextDraw(playerid, 275.000000, 205.000000, "LOZINKA:");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][23], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][23], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][23], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][23], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][23], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][23], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][23], 1);

    // "Uputstvo za login"
    NewLoginTD[playerid][24] = CreatePlayerTextDraw(playerid, 275.000000, 230.000000, "Unesite vasu lozinku u polje ispod.");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][24], 0.160000, 0.700000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][24], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][24], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][24], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][24], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][24], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][24], 1);

    NewLoginTD[playerid][25] = CreatePlayerTextDraw(playerid, 275.000000, 245.000000, "Imate 60 sekundi da se ulogujete.");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][25], 0.160000, 0.700000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][25], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][25], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][25], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][25], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][25], 1);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][25], 1);

    // Timer display "VREME: 60"
    NewLoginTD[playerid][26] = CreatePlayerTextDraw(playerid, 275.000000, 268.000000, "VREME: 60");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][26], 0.250000, 1.100000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][26], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][26], 0xFF0000FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][26], 1);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][26], 0x00000066);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][26], 2);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][26], 1);

    // Decorative corner TL
    NewLoginTD[playerid][27] = CreatePlayerTextDraw(playerid, 250.000000, 100.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][27], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][27], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][27], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][27], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][27], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][27], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][27], 0);

    // Decorative corner TR
    NewLoginTD[playerid][28] = CreatePlayerTextDraw(playerid, 600.000000, 100.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][28], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][28], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][28], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][28], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][28], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][28], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][28], 0);

    // Decorative corner BL
    NewLoginTD[playerid][29] = CreatePlayerTextDraw(playerid, 250.000000, 328.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][29], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][29], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][29], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][29], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][29], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][29], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][29], 0);

    // Decorative corner BR
    NewLoginTD[playerid][30] = CreatePlayerTextDraw(playerid, 600.000000, 328.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][30], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][30], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][30], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][30], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][30], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][30], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][30], 0);

    // Glowing effect linija bottom panel
    NewLoginTD[playerid][31] = CreatePlayerTextDraw(playerid, 250.000000, 342.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewLoginTD[playerid][31], 0.000000, 0.500000);
    PlayerTextDrawTextSize(playerid, NewLoginTD[playerid][31], 365.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewLoginTD[playerid][31], 1);
    PlayerTextDrawColor(playerid, NewLoginTD[playerid][31], 503316480);
    PlayerTextDrawUseBox(playerid, NewLoginTD[playerid][31], 1);
    PlayerTextDrawBoxColor(playerid, NewLoginTD[playerid][31], 503316480);
    PlayerTextDrawSetShadow(playerid, NewLoginTD[playerid][31], 0);
    PlayerTextDrawBackgroundColor(playerid, NewLoginTD[playerid][31], 255);
    PlayerTextDrawFont(playerid, NewLoginTD[playerid][31], 4);
    PlayerTextDrawSetProportional(playerid, NewLoginTD[playerid][31], 0);
}

// ========================= NEW REGISTER TD SYSTEM ============================== //

stock NewRegisterTDCreate(playerid)
{
    // Pozadina - full screen crno
    NewRegisterTD[playerid][0] = CreatePlayerTextDraw(playerid, -2.000000, -4.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][0], 0.000000, 51.500000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][0], 642.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][0], 128);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][0], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][0], 0);

    // Pozadinski panel - lijevi tamno plavi 
    NewRegisterTD[playerid][1] = CreatePlayerTextDraw(playerid, -2.000000, -4.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][1], 0.000000, 51.500000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][1], 220.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][1], 592137216);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][1], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][1], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][1], 0);

    // Linija - vertikalna izmedju panela
    NewRegisterTD[playerid][2] = CreatePlayerTextDraw(playerid, 217.000000, -4.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][2], 0.000000, 51.500000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][2], 3.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][2], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][2], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][2], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][2], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][2], 0);

    // Logo text "UNICATE"
    NewRegisterTD[playerid][3] = CreatePlayerTextDraw(playerid, 25.000000, 40.000000, "UNICATE");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][3], 0.600000, 2.200000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][3], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][3], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][3], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][3], 1);

    // Logo text "GAMING"
    NewRegisterTD[playerid][4] = CreatePlayerTextDraw(playerid, 25.000000, 70.000000, "GAMING");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][4], 0.600000, 2.200000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][4], -1);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][4], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][4], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][4], 1);

    // Logo text "RPG SERVER"
    NewRegisterTD[playerid][5] = CreatePlayerTextDraw(playerid, 25.000000, 100.000000, "RPG SERVER");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][5], 0.300000, 1.200000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][5], 0x0074c288);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][5], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][5], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][5], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][5], 1);

    // Dekorativna linija 
    NewRegisterTD[playerid][6] = CreatePlayerTextDraw(playerid, 25.000000, 130.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][6], 0.000000, 0.150000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][6], 170.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][6], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][6], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][6], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][6], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][6], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][6], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][6], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][6], 0);

    // Vlasnici tekst
    NewRegisterTD[playerid][7] = CreatePlayerTextDraw(playerid, 25.000000, 150.000000, "VLASNICI");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][7], 0.150000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][7], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][7], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][7], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][7], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][7], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][7], 1);

    NewRegisterTD[playerid][8] = CreatePlayerTextDraw(playerid, 25.000000, 165.000000, "Beka & Sloba");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][8], 0.200000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][8], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][8], -1);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][8], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][8], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][8], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][8], 1);

    // Developer tekst
    NewRegisterTD[playerid][9] = CreatePlayerTextDraw(playerid, 25.000000, 195.000000, "DEVELOPER");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][9], 0.150000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][9], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][9], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][9], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][9], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][9], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][9], 1);

    NewRegisterTD[playerid][10] = CreatePlayerTextDraw(playerid, 25.000000, 210.000000, "Beka");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][10], 0.200000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][10], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][10], -1);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][10], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][10], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][10], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][10], 1);

    // Mapper tekst
    NewRegisterTD[playerid][11] = CreatePlayerTextDraw(playerid, 25.000000, 240.000000, "MAPPER");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][11], 0.150000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][11], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][11], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][11], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][11], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][11], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][11], 1);

    NewRegisterTD[playerid][12] = CreatePlayerTextDraw(playerid, 25.000000, 255.000000, "Beka");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][12], 0.200000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][12], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][12], -1);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][12], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][12], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][12], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][12], 1);

    // Linija ispod credits
    NewRegisterTD[playerid][13] = CreatePlayerTextDraw(playerid, 25.000000, 285.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][13], 0.000000, 0.150000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][13], 170.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][13], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][13], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][13], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][13], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][13], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][13], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][13], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][13], 0);

    // Forum info
    NewRegisterTD[playerid][14] = CreatePlayerTextDraw(playerid, 25.000000, 300.000000, "www.ug-ogc.com");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][14], 0.130000, 0.700000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][14], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][14], 0xAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][14], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][14], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][14], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][14], 1);

    // =========== DESNA STRANA - REGISTER PANEL =========== //

    // Register panel pozadina
    NewRegisterTD[playerid][15] = CreatePlayerTextDraw(playerid, 235.000000, 10.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][15], 0.000000, 52.000000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][15], 395.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][15], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][15], 2281701503);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][15], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][15], 2281701503);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][15], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][15], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][15], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][15], 0);

    // Register panel border top
    NewRegisterTD[playerid][16] = CreatePlayerTextDraw(playerid, 235.000000, 10.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][16], 0.000000, 0.400000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][16], 395.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][16], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][16], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][16], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][16], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][16], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][16], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][16], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][16], 0);

    // "DOBRADOSLI" naslov
    NewRegisterTD[playerid][17] = CreatePlayerTextDraw(playerid, 260.000000, 25.000000, "DOBRADOSLI NA");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][17], 0.250000, 1.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][17], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][17], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][17], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][17], 0x00000033);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][17], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][17], 1);

    // "UNICATE GAMING" naslov
    NewRegisterTD[playerid][18] = CreatePlayerTextDraw(playerid, 260.000000, 44.000000, "UNICATE GAMING RPG");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][18], 0.380000, 1.500000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][18], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][18], -1);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][18], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][18], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][18], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][18], 1);

    // Podnaslov
    NewRegisterTD[playerid][19] = CreatePlayerTextDraw(playerid, 260.000000, 68.000000, "Registrujte se da biste zapoceli igranje na serveru!");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][19], 0.160000, 0.700000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][19], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][19], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][19], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][19], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][19], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][19], 1);

    // Separator line
    NewRegisterTD[playerid][20] = CreatePlayerTextDraw(playerid, 260.000000, 85.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][20], 0.000000, 0.100000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][20], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][20], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][20], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][20], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][20], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][20], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][20], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][20], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][20], 0);

    // LOZINKA field
    NewRegisterTD[playerid][21] = CreatePlayerTextDraw(playerid, 260.000000, 100.000000, "LOZINKA");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][21], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][21], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][21], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][21], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][21], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][21], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][21], 1);

    // Lozinka box
    NewRegisterTD[playerid][22] = CreatePlayerTextDraw(playerid, 260.000000, 118.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][22], 0.000000, 1.200000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][22], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][22], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][22], 809500672);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][22], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][22], 809500672);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][22], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][22], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][22], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][22], 0);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][22], true);

    // Lozinka value (clickable)
    NewRegisterTD[playerid][23] = CreatePlayerTextDraw(playerid, 268.000000, 116.000000, "Kliknite da unesete lozinku...");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][23], 0.200000, 0.900000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][23], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][23], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][23], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][23], 0);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][23], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][23], 1);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][23], true);

    // EMAIL field
    NewRegisterTD[playerid][24] = CreatePlayerTextDraw(playerid, 260.000000, 145.000000, "EMAIL");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][24], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][24], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][24], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][24], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][24], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][24], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][24], 1);

    // Email box
    NewRegisterTD[playerid][25] = CreatePlayerTextDraw(playerid, 260.000000, 163.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][25], 0.000000, 1.200000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][25], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][25], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][25], 809500672);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][25], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][25], 809500672);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][25], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][25], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][25], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][25], 0);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][25], true);

    // Email value
    NewRegisterTD[playerid][26] = CreatePlayerTextDraw(playerid, 268.000000, 161.000000, "Kliknite da unesete email...");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][26], 0.200000, 0.900000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][26], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][26], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][26], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][26], 0);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][26], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][26], 1);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][26], true);

    // SPOL field
    NewRegisterTD[playerid][27] = CreatePlayerTextDraw(playerid, 260.000000, 190.000000, "SPOL");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][27], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][27], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][27], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][27], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][27], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][27], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][27], 1);

    // Spol box
    NewRegisterTD[playerid][28] = CreatePlayerTextDraw(playerid, 260.000000, 208.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][28], 0.000000, 1.200000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][28], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][28], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][28], 809500672);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][28], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][28], 809500672);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][28], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][28], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][28], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][28], 0);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][28], true);

    // Spol value
    NewRegisterTD[playerid][29] = CreatePlayerTextDraw(playerid, 268.000000, 206.000000, "Odaberite spol...");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][29], 0.200000, 0.900000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][29], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][29], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][29], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][29], 0);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][29], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][29], 1);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][29], true);

    // DRZAVLJANSTVO field
    NewRegisterTD[playerid][30] = CreatePlayerTextDraw(playerid, 260.000000, 235.000000, "DRZAVLJANSTVO");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][30], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][30], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][30], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][30], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][30], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][30], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][30], 1);

    // Drzavljanstvo box
    NewRegisterTD[playerid][31] = CreatePlayerTextDraw(playerid, 260.000000, 253.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][31], 0.000000, 1.200000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][31], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][31], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][31], 809500672);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][31], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][31], 809500672);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][31], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][31], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][31], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][31], 0);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][31], true);

    // Drzavljanstvo value
    NewRegisterTD[playerid][32] = CreatePlayerTextDraw(playerid, 268.000000, 251.000000, "Odaberite drzavljanstvo...");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][32], 0.200000, 0.900000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][32], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][32], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][32], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][32], 0);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][32], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][32], 1);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][32], true);

    // GODINE field
    NewRegisterTD[playerid][33] = CreatePlayerTextDraw(playerid, 260.000000, 280.000000, "GODINE");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][33], 0.180000, 0.800000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][33], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][33], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][33], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][33], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][33], 2);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][33], 1);

    // Godine box
    NewRegisterTD[playerid][34] = CreatePlayerTextDraw(playerid, 260.000000, 298.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][34], 0.000000, 1.200000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][34], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][34], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][34], 809500672);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][34], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][34], 809500672);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][34], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][34], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][34], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][34], 0);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][34], true);

    // Godine value
    NewRegisterTD[playerid][35] = CreatePlayerTextDraw(playerid, 268.000000, 296.000000, "Unesite vase godine...");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][35], 0.200000, 0.900000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][35], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][35], 0xAAAAAAAAFF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][35], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][35], 0);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][35], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][35], 1);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][35], true);

    // REGISTER dugme
    NewRegisterTD[playerid][36] = CreatePlayerTextDraw(playerid, 260.000000, 330.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][36], 0.000000, 2.000000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][36], 370.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][36], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][36], 0x0074c2FF);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][36], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][36], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][36], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][36], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][36], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][36], 0);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][36], true);

    // REGISTER tekst
    NewRegisterTD[playerid][37] = CreatePlayerTextDraw(playerid, 370.000000, 333.000000, "REGISTRUJ SE");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][37], 0.300000, 1.200000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][37], 2);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][37], -1);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][37], 1);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][37], 0x00000066);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][37], 1);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][37], 1);
    PlayerTextDrawSetSelectable(playerid, NewRegisterTD[playerid][37], true);

    // Decorative corners
    NewRegisterTD[playerid][38] = CreatePlayerTextDraw(playerid, 235.000000, 10.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][38], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][38], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][38], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][38], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][38], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][38], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][38], 0);

    NewRegisterTD[playerid][39] = CreatePlayerTextDraw(playerid, 615.000000, 10.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][39], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][39], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][39], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][39], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][39], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][39], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][39], 0);

    NewRegisterTD[playerid][40] = CreatePlayerTextDraw(playerid, 235.000000, 355.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][40], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][40], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][40], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][40], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][40], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][40], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][40], 0);

    NewRegisterTD[playerid][41] = CreatePlayerTextDraw(playerid, 615.000000, 355.000000, "LD_BEAT:CHIT");
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][41], 12.000000, 12.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][41], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][41], 0x0074c2FF);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][41], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][41], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][41], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][41], 0);

    // Glow effect
    NewRegisterTD[playerid][42] = CreatePlayerTextDraw(playerid, 235.000000, 360.000000, "LD_SPAC:white");
    PlayerTextDrawLetterSize(playerid, NewRegisterTD[playerid][42], 0.000000, 0.500000);
    PlayerTextDrawTextSize(playerid, NewRegisterTD[playerid][42], 395.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, NewRegisterTD[playerid][42], 1);
    PlayerTextDrawColor(playerid, NewRegisterTD[playerid][42], 503316480);
    PlayerTextDrawUseBox(playerid, NewRegisterTD[playerid][42], 1);
    PlayerTextDrawBoxColor(playerid, NewRegisterTD[playerid][42], 503316480);
    PlayerTextDrawSetShadow(playerid, NewRegisterTD[playerid][42], 0);
    PlayerTextDrawBackgroundColor(playerid, NewRegisterTD[playerid][42], 255);
    PlayerTextDrawFont(playerid, NewRegisterTD[playerid][42], 4);
    PlayerTextDrawSetProportional(playerid, NewRegisterTD[playerid][42], 0);
}

stock NewLoginTDShow(playerid)
{
    for(new i = 0; i < 32; i++)
    {
        PlayerTextDrawShow(playerid, NewLoginTD[playerid][i]);
    }
}

stock NewLoginTDHide(playerid)
{
    for(new i = 0; i < 32; i++)
    {
        PlayerTextDrawHide(playerid, NewLoginTD[playerid][i]);
        PlayerTextDrawDestroy(playerid, NewLoginTD[playerid][i]);
        NewLoginTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
    }
}

stock NewRegisterTDShow(playerid)
{
    for(new i = 0; i < 43; i++)
    {
        PlayerTextDrawShow(playerid, NewRegisterTD[playerid][i]);
    }
}

stock NewRegisterTDHide(playerid)
{
    for(new i = 0; i < 43; i++)
    {
        PlayerTextDrawHide(playerid, NewRegisterTD[playerid][i]);
        PlayerTextDrawDestroy(playerid, NewRegisterTD[playerid][i]);
        NewRegisterTD[playerid][i] = PlayerText:INVALID_TEXT_DRAW;
    }
}

stock NewRegisterTDControl(playerid, bool:show)
{
    if(show == true)
    {
        NewRegisterTDCreate(playerid);
        NewRegisterTDShow(playerid);
        ShowedRegister[playerid] = true;
    }
    else if(show == false)
    {
        NewRegisterTDHide(playerid);
        ShowedRegister[playerid] = false;
    }
}